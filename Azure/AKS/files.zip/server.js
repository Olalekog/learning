const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Application data
const data = {
  course: 'Azure DevOps - Azure Kubernetes Service',
  fullName: {
    firstName: 'Olalekan',
    middleName: 'Gabriel',
    lastName: 'Ogundare'
  },
  status: 'In Progress'
};

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// API endpoint returning the data as JSON
app.get('/api/info', (req, res) => {
  res.json({
    course: data.course,
    fullName: `${data.fullName.firstName} ${data.fullName.middleName} ${data.fullName.lastName}`,
    status: data.status
  });
});

// Simple health check endpoint (useful for Kubernetes liveness/readiness probes)
app.get('/healthz', (req, res) => {
  res.status(200).json({ status: 'healthy' });
});

// Serve the main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
